
public class Main {
    public static void main(String[] args) {
        // Write some code here to test your program

        // Once you have done the class which implements the actual application logic,
        // all you need to write here is:
        // Calculator calculator = new Calculator();
        // calculator.start();
    }
}
